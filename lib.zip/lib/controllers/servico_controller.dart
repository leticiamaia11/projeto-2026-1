import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'veículo_controller.dart';
import '../models/registroServico.dart';
import '../models/gasto.dart';

class ServicoController extends ChangeNotifier {
  final VeiculoController veiculoController;
  final SupabaseClient _supabase = Supabase.instance.client;

  List<RegistroServico> historicoGlobal = [];
  List<Gasto> listaDeGastos = [];

  bool carregando = false;

  ServicoController({required this.veiculoController});

  /// Carrega os dados do relatório a partir do Supabase
  Future<void> buscarDadosParaRelatorio() async {
    carregando = true;
    notifyListeners();

    try {
      final dadosServicos = await _supabase
          .from('registro_servicos')
          .select()
          .order('data', ascending: false);

      historicoGlobal = (dadosServicos as List)
          .map((mapa) => RegistroServico.fromMap(mapa))
          .toList();

      final dadosGastos = await _supabase
          .from('gasto')
          .select()
          .order('data', ascending: false);

      listaDeGastos = (dadosGastos as List)
          .map((mapa) => Gasto.fromMap(mapa))
          .toList();
    } catch (e) {
      debugPrint("Erro ao buscar dados do relatório: $e");
    } finally {
      carregando = false;
      notifyListeners();
    }
  }

  /// Adiciona um novo serviço prestado
  Future<bool> adicionarServico({
    required String placa,
    required String descricao,
    required double valor,
    required int duracao,
    required DateTime dataServico,
    String status = 'Pago',
  }) async {
    try {
      // Busca o ID do veículo correspondente à placa
      final veiculoExistente = await _supabase
          .from('veiculo')
          .select('id')
          .eq('placa', placa.toUpperCase().trim())
          .maybeSingle();

      if (veiculoExistente == null) {
        debugPrint("Erro: Veículo com a placa $placa não foi encontrado.");
        return false;
      }

      final String uuidVeiculo = veiculoExistente['id'];

      final novoServico = RegistroServico(
        descricao: descricao,
        valor: valor,
        placaVeiculo: placa.toUpperCase().trim(),
        duracaoEmHoras: duracao,
        dataInformada: dataServico,
        concluido: true,
        veiculoId: uuidVeiculo,
        status: status,
      );

      // Persiste no Supabase e recupera o objeto criado com o ID gerado pelo banco
      final resposta = await _supabase
          .from('registro_servicos')
          .insert(novoServico.toMap())
          .select()
          .single();

      final servicoSalvo = RegistroServico.fromMap(resposta);

      historicoGlobal.insert(0, servicoSalvo);
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint("Erro ao registrar serviço no Supabase: $e");
      return false;
    }
  }

  /// Adiciona uma nova saída financeira (Gasto)
  Future<bool> adicionarGasto(Gasto gasto) async {
    try {
      final mapaGasto = gasto.toMap();

      // Inserção com retorno do registro completo
      final resposta = await _supabase
          .from('gasto')
          .insert(mapaGasto)
          .select()
          .single();

      final gastoSalvo = Gasto.fromMap(resposta);

      listaDeGastos.insert(0, gastoSalvo);
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint("Erro ao registrar saída financeira no Supabase: $e");
      return false;
    }
  }

  /// Cálculo do saldo atual com tratamento seguro
  double get saldoAtualReal {
    final receitasPagas = historicoGlobal
        .where((servico) => servico.status.toLowerCase() == 'pago')
        .fold(0.0, (soma, servico) => soma + servico.valor);

    final despesasPagas = listaDeGastos
        .where((gasto) => gasto.status.toLowerCase() == 'pago')
        .fold(0.0, (soma, gasto) => soma + gasto.valor);

    return receitasPagas - despesasPagas;
  }

  /// Receita bruta dos serviços pagos
double get faturamentoBruto {
  return historicoGlobal
      .where((servico) => servico.status.toLowerCase() == 'pago')
      .fold(0.0, (soma, servico) => soma + servico.valor);
}

/// ISS de 6% sobre o faturamento bruto
double get totalImpostoIss {
  return faturamentoBruto * 0.06;
}

/// Receita após a dedução do ISS
double get receitaLiquidaTotal {
  return faturamentoBruto - totalImpostoIss;
}

/// Total de despesas pagas
double get totalDespesasPagas {
  return listaDeGastos
      .where((gasto) => gasto.status.toLowerCase() == 'pago')
      .fold(0.0, (soma, gasto) => soma + gasto.valor);
}

/// Resultado final do DRE
double get lucroLiquidoReal {
  return receitaLiquidaTotal - totalDespesasPagas;
}
}

