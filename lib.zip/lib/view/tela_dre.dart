import 'package:flutter/material.dart';
import 'package:projeto_integrador/controllers/servico_controller.dart';

class TelaDRE extends StatelessWidget {
  final ServicoController servicoController;

  const TelaDRE({super.key, required this.servicoController});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9FAFC),
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'DRE Simples',
          style: TextStyle(
            color: Color(0xFF1E40AF),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Color(0xFF1E40AF)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListenableBuilder(
        listenable: servicoController,
        builder: (context, _) {
          if (servicoController.carregando) {
            return const Center(child: CircularProgressIndicator());
          }

          final bruto = servicoController.faturamentoBruto;
          final impostos = servicoController.totalImpostoIss;
          final receitaLiquida = servicoController.receitaLiquidaTotal;
          final despesas = servicoController.totalDespesasPagas;
          final lucroLiquido = servicoController.lucroLiquidoReal;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Demonstrativo do Resultado do Exercício',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.black54,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),

                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        _buildLinhaDRE(
                          titulo: '(+) Receita Bruta (Vendas)',
                          valor: bruto,
                          corTexto: Colors.green[800]!,
                          isBold: true,
                        ),
                        const Divider(height: 24),

                        _buildLinhaDRE(
                          titulo: '(-) Impostos Fiscais (ISS)',
                          valor: impostos,
                          corTexto: Colors.red[700]!,
                        ),
                        const Divider(height: 24),

                        _buildLinhaDRE(
                          titulo: '(=) Receita Líquida',
                          valor: receitaLiquida,
                          corTexto: Colors.blue[900]!,
                          isBold: true,
                        ),
                        const Divider(height: 24),

                        _buildLinhaDRE(
                          titulo: '(-) Despesas Operacionais',
                          valor: despesas,
                          corTexto: Colors.red[700]!,
                        ),
                        const Divider(height: 32, thickness: 1.5),

                        //Resultado final
                        _buildLinhaDRE(
                          titulo: lucroLiquido >= 0
                              ? '(=) LUCRO LÍQUIDO'
                              : '(=) PREJUÍZO LÍQUIDO',
                          valor: lucroLiquido,
                          corTexto: lucroLiquido >= 0
                              ? Colors.green[900]!
                              : Colors.red[900]!,
                          isBold: true,
                          tamanhoFonte: 18,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildLinhaDRE({
    required String titulo,
    required double valor,
    required Color corTexto,
    bool isBold = false,
    double tamanhoFonte = 15,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            titulo,
            style: TextStyle(
              fontSize: tamanhoFonte,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: Colors.black87,
            ),
          ),
        ),
        Text(
          'R\$ ${valor.toStringAsFixed(2).replaceAll('.', ',')}',
          style: TextStyle(
            fontSize: tamanhoFonte,
            fontWeight: isBold ? FontWeight.bold : FontWeight.w600,
            color: corTexto,
          ),
        ),
      ],
    );
  }
}