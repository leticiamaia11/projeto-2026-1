class RegistroServico {
  String? id;
  String descricao;
  double valor;
  DateTime data;
  String placaVeiculo;
  bool concluido;
  int duracaoEmHoras;
  String? veiculoId;
  final String status; //ADICIONADO

  //CAMPOS CONTÁBEIS
  final String? numeroNotaFiscal;
  final double aliquotaIss;

  RegistroServico({
    this.id,
    required this.descricao,
    required this.valor,
    required this.placaVeiculo,
    required this.duracaoEmHoras,
    this.concluido = false,
    this.veiculoId,
    this.status = 'Pago', //ADICIONADO
    this.numeroNotaFiscal,
    this.aliquotaIss = 5.0, //5% de ISS municipal
    DateTime? dataInformada,
  }) : data = dataInformada ?? DateTime.now();

  DateTime get horarioTermino => data.add(Duration(hours: duracaoEmHoras));

  factory RegistroServico.fromMap(Map<String, dynamic> map) {
    return RegistroServico(
      id: map['id'],
      descricao: map['descricao'] ?? '',
      valor: (map['valor'] as num? ?? 0.0).toDouble(),
      // Mapeando a coluna 'data' do banco:
      dataInformada: map['data'] != null ? DateTime.parse(map['data']) : null,
      // Mapeando as colunas exatamente como estão na imagem do banco:
      placaVeiculo: map['placaveiculo'] ?? '',
      status: map['status'] ?? 'Pago', //ADICIONADO
      numeroNotaFiscal: map['numero_nota_fiscal']?.toString(),
      aliquotaIss: double.tryParse(map['aliquota_iss'].toString()) ?? 5.0,
      duracaoEmHoras: map['duracaoemhoras'] ?? 0,
      concluido: map['concluido'] ?? false,
      veiculoId: map['veiculo_id'],
    );
  }

  double get valorBruto => valor;
  double get valorImpostoIss => valor * (aliquotaIss / 100);
  double get receitaLiquida => valor - valorImpostoIss;

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'descricao': descricao,
      'valor': valor,
      'data': data.toIso8601String(),
      'placaveiculo': placaVeiculo,
      'status': status, //ADICIONADO
      'numero_nota_fiscal': numeroNotaFiscal,
      'aliquota_iss': aliquotaIss,
      'duracaoemhoras': duracaoEmHoras,
      'concluido': concluido,
      if (veiculoId != null) 'veiculo_id': veiculoId,
    };
  }
}